with recent as (
    select trip_id
    from {{ ref('int_trips_cleaned') }}
    where meter_on::date >= (
        select max(meter_on)::date - interval '35 day'
        from {{ ref('int_trips_cleaned') }}
    )
),
duplicates as (
    select trip_id, count(*) as n
    from recent
    group by trip_id
    having count(*) > 1
)
select * from duplicates